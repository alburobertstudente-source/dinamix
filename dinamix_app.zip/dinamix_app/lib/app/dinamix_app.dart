import 'dart:async';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../ble/connection_manager.dart';
import '../ble/device_scanner.dart';
import '../core/app_error.dart';
import '../data/session_recorder.dart';
import '../settings/app_settings.dart';
import '../ui/screens/analysis_screen.dart';
import '../ui/screens/devices_screen.dart';
import '../ui/screens/home_screen.dart';
import '../ui/screens/live_screen.dart';
import '../ui/screens/logger_screen.dart';
import '../ui/theme.dart';
import '../ui/widgets/common.dart';
import 'services.dart';

/// Selected tab, and session to open in the analysis tab.
class NavController extends ChangeNotifier {
  int index = 0;
  int? analysisSessionId;

  static const int devices = 1;
  static const int live = 2;
  static const int analysis = 3;
  static const int logger = 4;

  void go(int tab) {
    index = tab;
    notifyListeners();
  }

  void openAnalysis(int sessionId) {
    analysisSessionId = sessionId;
    go(analysis);
  }
}

class DinamixApp extends StatefulWidget {
  const DinamixApp({super.key, required this.services});

  final AppServices services;

  @override
  State<DinamixApp> createState() => _DinamixAppState();
}

class _DinamixAppState extends State<DinamixApp> with WidgetsBindingObserver {
  final GlobalKey<ScaffoldMessengerState> _messenger = GlobalKey<ScaffoldMessengerState>();
  late final StreamSubscription<AppError> _errors;
  final NavController _nav = NavController();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _errors = ErrorCenter.instance.errors.listen((error) {
      _messenger.currentState?.showSnackBar(SnackBar(content: Text(error.message)));
    });
    final recovered = widget.services.recoveredSessions;
    if (recovered > 0) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        _messenger.currentState?.showSnackBar(SnackBar(
          content: Text('$recovered sessione/i interrotta/e: dati recuperati nel Data Logger.'),
        ));
      });
    }
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    final services = widget.services;
    final visible = state == AppLifecycleState.resumed;
    services.hub.setForeground(visible);
    // Nothing is left in memory if Android kills the process in background.
    if (state == AppLifecycleState.paused || state == AppLifecycleState.detached) {
      services.recorder.flush();
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _errors.cancel();
    _nav.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final services = widget.services;
    return MultiProvider(
      providers: [
        Provider<AppServices>.value(value: services),
        ChangeNotifierProvider<AppSettings>.value(value: services.settings),
        ChangeNotifierProvider<ConnectionManager>.value(value: services.connection),
        ChangeNotifierProvider<DeviceScanner>.value(value: services.scanner),
        ChangeNotifierProvider<SessionRecorder>.value(value: services.recorder),
        ChangeNotifierProvider<NavController>.value(value: _nav),
      ],
      child: Consumer<AppSettings>(
        builder: (context, settings, _) => MaterialApp(
          title: 'DinamiX',
          debugShowCheckedModeBanner: false,
          scaffoldMessengerKey: _messenger,
          theme: buildTheme(Brightness.light),
          darkTheme: buildTheme(Brightness.dark),
          themeMode: settings.themeMode,
          home: const AppShell(),
        ),
      ),
    );
  }
}

class AppShell extends StatelessWidget {
  const AppShell({super.key});

  @override
  Widget build(BuildContext context) {
    final nav = context.watch<NavController>();
    final simulation = context.select<AppSettings, bool>((s) => s.simulationMode);
    return Scaffold(
      body: Column(
        children: [
          if (simulation) SafeArea(bottom: false, child: const SimulationBanner()),
          Expanded(
            child: MediaQuery.removePadding(
              context: context,
              removeTop: simulation,
              child: IndexedStack(
                index: nav.index,
                children: const [
                  HomeScreen(),
                  DevicesScreen(),
                  LiveScreen(),
                  AnalysisScreen(),
                  LoggerScreen(),
                ],
              ),
            ),
          ),
        ],
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: nav.index,
        onDestinationSelected: nav.go,
        destinations: const [
          NavigationDestination(
              icon: Icon(Icons.dashboard_outlined), selectedIcon: Icon(Icons.dashboard), label: 'Home'),
          NavigationDestination(
              icon: Icon(Icons.bluetooth_searching), selectedIcon: Icon(Icons.bluetooth), label: 'Dispositivi'),
          NavigationDestination(
              icon: Icon(Icons.show_chart), selectedIcon: Icon(Icons.show_chart), label: 'Live'),
          NavigationDestination(
              icon: Icon(Icons.analytics_outlined), selectedIcon: Icon(Icons.analytics), label: 'Analisi'),
          NavigationDestination(
              icon: Icon(Icons.fiber_manual_record_outlined),
              selectedIcon: Icon(Icons.fiber_manual_record),
              label: 'Logger'),
        ],
      ),
    );
  }
}
