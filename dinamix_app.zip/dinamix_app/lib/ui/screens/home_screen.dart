import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../app/dinamix_app.dart';
import '../../app/services.dart';
import '../../ble/connection_manager.dart';
import '../../ble/device_scanner.dart';
import '../../ble/transport/ble_transport.dart';
import '../../data/session_recorder.dart';
import '../../domain/sensor_kind.dart';
import '../../settings/app_settings.dart';
import '../format.dart';
import '../theme.dart';
import '../widgets/common.dart';
import 'diagnostics_screen.dart';
import 'settings_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final connection = context.watch<ConnectionManager>();
    final scanner = context.watch<DeviceScanner>();
    final settings = context.watch<AppSettings>();
    final recorder = context.watch<SessionRecorder>();
    final nav = context.read<NavController>();
    final services = context.read<AppServices>();
    final last = settings.knownDevices.isEmpty ? null : settings.knownDevices.first;

    return Scaffold(
      appBar: AppBar(
        titleSpacing: 16,
        title: const Row(
          children: [
            DinamixLogo(size: 32),
            SizedBox(width: 10),
            Text('DinamiX'),
          ],
        ),
        actions: [
          IconButton(
            tooltip: 'Diagnostica',
            icon: const Icon(Icons.troubleshoot),
            onPressed: () => Navigator.of(context)
                .push(MaterialPageRoute<void>(builder: (_) => const DiagnosticsScreen())),
          ),
          IconButton(
            tooltip: 'Impostazioni',
            icon: const Icon(Icons.settings_outlined),
            onPressed: () => Navigator.of(context)
                .push(MaterialPageRoute<void>(builder: (_) => const SettingsScreen())),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
        children: [
          _ConnectionCard(connection: connection, last: last),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(child: _BluetoothTile(status: scanner.adapterStatus, scanner: scanner)),
              const SizedBox(width: 12),
              const Expanded(child: _BatteryTile()),
            ],
          ),
          if (recorder.isActive) ...[
            const SizedBox(height: 12),
            Card(
              child: ListTile(
                leading: const Icon(Icons.fiber_manual_record, color: Palette.danger),
                title: Text(recorder.sessionName),
                subtitle: Text(recorder.state == RecorderState.paused
                    ? 'In pausa'
                    : 'Registrazione in corso'),
                trailing: const Icon(Icons.chevron_right),
                onTap: () => nav.go(NavController.logger),
              ),
            ),
          ],
          const SectionTitle('Sensori attivi'),
          _ActiveSensors(connection: connection, services: services),
          const SectionTitle('Accesso rapido'),
          Row(
            children: [
              Expanded(
                child: _QuickAction(
                  icon: Icons.show_chart,
                  label: 'Live',
                  onTap: () => nav.go(NavController.live),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: _QuickAction(
                  icon: Icons.fiber_manual_record_outlined,
                  label: 'Registra',
                  onTap: () => nav.go(NavController.logger),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: _QuickAction(
                  icon: Icons.analytics_outlined,
                  label: 'Analisi',
                  onTap: () => nav.go(NavController.analysis),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _ConnectionCard extends StatelessWidget {
  const _ConnectionCard({required this.connection, required this.last});

  final ConnectionManager connection;
  final KnownDevice? last;

  (String, Color) _status(BuildContext context) => switch (connection.phase) {
        ConnectionPhase.ready => ('Connesso', Palette.ok),
        ConnectionPhase.connecting => ('Connessione…', Palette.warning),
        ConnectionPhase.discovering => ('Lettura servizi…', Palette.warning),
        ConnectionPhase.subscribing => ('Attivazione sensori…', Palette.warning),
        ConnectionPhase.reconnecting =>
          ('Riconnessione, tentativo ${connection.reconnectAttempt}…', Palette.warning),
        ConnectionPhase.failed => ('Connessione non riuscita', Palette.danger),
        ConnectionPhase.idle =>
          ('Non connesso', Theme.of(context).colorScheme.onSurfaceVariant),
      };

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final (label, color) = _status(context);
    final shown = connection.phase == ConnectionPhase.idle ? null : connection.device;
    final services = context.read<AppServices>();
    final nav = context.read<NavController>();
    final known = last;
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                StatusDot(color),
                const SizedBox(width: 8),
                Expanded(child: Text(label, style: theme.textTheme.labelLarge)),
                if (connection.rssi != null && connection.isReady) SignalBars(connection.rssi!),
              ],
            ),
            const SizedBox(height: 12),
            Text(
              shown != null ? shown.name : 'SensorTile.box PRO',
              style: theme.textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w700),
            ),
            const SizedBox(height: 4),
            Text(
              shown != null
                  ? (shown.advertising?.firmwareLabel ?? 'Firmware non identificato')
                  : (known == null
                      ? 'Nessuna connessione precedente'
                      : 'Ultima connessione: ${known.name}, ${formatRelative(known.lastConnectedMs)}'),
              style: theme.textTheme.bodyMedium?.copyWith(color: theme.colorScheme.onSurfaceVariant),
            ),
            const SizedBox(height: 14),
            if (connection.isReady || connection.isBusy)
              SizedBox(
                width: double.infinity,
                child: OutlinedButton.icon(
                  icon: const Icon(Icons.link_off),
                  label: const Text('Disconnetti'),
                  onPressed: connection.disconnect,
                ),
              )
            else
              Row(
                children: [
                  Expanded(
                    child: FilledButton.icon(
                      icon: const Icon(Icons.bluetooth_searching),
                      label: const Text('Collega'),
                      onPressed: () {
                        nav.go(NavController.devices);
                        context.read<DeviceScanner>().start();
                      },
                    ),
                  ),
                  if (known != null && !connection.isSimulated) ...[
                    const SizedBox(width: 10),
                    Expanded(
                      child: OutlinedButton(
                        onPressed: () => services.connectTo(DeviceRef(known.id, known.name)),
                        child: const Text('Ricollega', overflow: TextOverflow.ellipsis),
                      ),
                    ),
                  ],
                ],
              ),
          ],
        ),
      ),
    );
  }
}

class _BluetoothTile extends StatelessWidget {
  const _BluetoothTile({required this.status, required this.scanner});

  final AdapterStatus status;
  final DeviceScanner scanner;

  @override
  Widget build(BuildContext context) {
    final (label, color) = switch (status) {
      AdapterStatus.on => ('Attivo', Palette.ok),
      AdapterStatus.off => ('Spento', Palette.danger),
      AdapterStatus.turningOn => ('In attivazione', Palette.warning),
      AdapterStatus.turningOff => ('In spegnimento', Palette.warning),
      AdapterStatus.unauthorized => ('Non autorizzato', Palette.danger),
      AdapterStatus.unsupported => ('Non supportato', Palette.danger),
      AdapterStatus.unknown => ('Sconosciuto', Palette.warning),
    };
    return _InfoTile(
      icon: Icons.bluetooth,
      title: 'Bluetooth',
      value: label,
      valueColor: color,
      onTap: status == AdapterStatus.off || status == AdapterStatus.unauthorized
          ? scanner.turnOnBluetooth
          : null,
    );
  }
}

class _BatteryTile extends StatelessWidget {
  const _BatteryTile();

  @override
  Widget build(BuildContext context) {
    final services = context.read<AppServices>();
    return ListenableBuilder(
      listenable: services.hub.frame,
      builder: (context, _) {
        final battery = services.hub.latest(SensorKind.battery);
        final fresh = services.hub.isReceiving(SensorKind.battery);
        if (battery == null || !fresh) {
          return const _InfoTile(
              icon: Icons.battery_unknown_outlined, title: 'Batteria', value: 'Non disponibile');
        }
        final level = battery.values[0];
        final status = battery.values[3].toInt();
        return _InfoTile(
          icon: status == 3 ? Icons.battery_charging_full : Icons.battery_full,
          title: 'Batteria',
          value: '${level.toStringAsFixed(0)} %',
          valueColor: level < 15 ? Palette.danger : null,
        );
      },
    );
  }
}

class _InfoTile extends StatelessWidget {
  const _InfoTile({
    required this.icon,
    required this.title,
    required this.value,
    this.valueColor,
    this.onTap,
  });

  final IconData icon;
  final String title;
  final String value;
  final Color? valueColor;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Card(
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Icon(icon, size: 20, color: theme.colorScheme.onSurfaceVariant),
              const SizedBox(height: 10),
              Text(title,
                  style: theme.textTheme.bodySmall
                      ?.copyWith(color: theme.colorScheme.onSurfaceVariant)),
              const SizedBox(height: 2),
              Text(
                value,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: theme.textTheme.titleMedium
                    ?.copyWith(fontWeight: FontWeight.w600, color: valueColor),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _ActiveSensors extends StatelessWidget {
  const _ActiveSensors({required this.connection, required this.services});

  final ConnectionManager connection;
  final AppServices services;

  @override
  Widget build(BuildContext context) {
    final kinds = connection.activeKinds.toList()..sort((a, b) => a.index.compareTo(b.index));
    if (!connection.isReady || kinds.isEmpty) {
      return Card(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Text(
            'Collega il dispositivo per vedere i sensori resi disponibili dal firmware.',
            style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant),
          ),
        ),
      );
    }
    return Card(
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 6),
        child: ListenableBuilder(
          listenable: services.hub.frame,
          builder: (context, _) => Column(
            children: [
              for (final kind in kinds)
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 7),
                  child: Row(
                    children: [
                      StatusDot(
                        services.hub.isReceiving(kind)
                            ? Palette.ok
                            : Theme.of(context).colorScheme.outlineVariant,
                        size: 8,
                      ),
                      const SizedBox(width: 10),
                      Expanded(child: Text(kind.label)),
                      Text('${services.hub.rateHz(kind).toStringAsFixed(1)} Hz',
                          style: numericStyle.copyWith(
                              fontSize: 13,
                              color: Theme.of(context).colorScheme.onSurfaceVariant)),
                    ],
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}

class _QuickAction extends StatelessWidget {
  const _QuickAction({required this.icon, required this.label, required this.onTap});

  final IconData icon;
  final String label;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) => Card(
        clipBehavior: Clip.antiAlias,
        child: InkWell(
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 16),
            child: Column(
              children: [
                Icon(icon, color: Theme.of(context).colorScheme.primary),
                const SizedBox(height: 8),
                Text(label, style: Theme.of(context).textTheme.labelMedium),
              ],
            ),
          ),
        ),
      );
}
