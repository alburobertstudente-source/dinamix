import 'package:flutter/material.dart';

/// Brand blue of the DinamiX logo, on neutral surfaces.
class Palette {
  static const Color brand = Color(0xFF0B6FDB);
  static const Color brandBright = Color(0xFF4DA3FF);

  static const Color darkBackground = Color(0xFF070A0F);
  static const Color darkSurface = Color(0xFF10151D);
  static const Color darkSurfaceHigh = Color(0xFF18202B);
  static const Color darkOutline = Color(0xFF263140);

  static const Color lightBackground = Color(0xFFF5F7FA);
  static const Color lightSurface = Color(0xFFFFFFFF);
  static const Color lightOutline = Color(0xFFDDE3EA);

  static const Color ok = Color(0xFF2FBF71);
  static const Color warning = Color(0xFFF2A93B);
  static const Color danger = Color(0xFFE5534B);
  static const Color simulation = Color(0xFFF2A93B);

  /// X, Y, Z and 4th channel: distinguishable also with color vision deficiency.
  static const List<Color> axes = [
    Color(0xFF4DA3FF),
    Color(0xFFF2703D),
    Color(0xFF2FBF9B),
    Color(0xFFB98CFF),
  ];
}

ThemeData buildTheme(Brightness brightness) {
  final dark = brightness == Brightness.dark;
  final scheme = ColorScheme.fromSeed(
    seedColor: Palette.brand,
    brightness: brightness,
  ).copyWith(
    primary: dark ? Palette.brandBright : Palette.brand,
    onPrimary: dark ? const Color(0xFF00203F) : Colors.white,
    surface: dark ? Palette.darkSurface : Palette.lightSurface,
    surfaceContainerHighest: dark ? Palette.darkSurfaceHigh : const Color(0xFFEDF1F5),
    outlineVariant: dark ? Palette.darkOutline : Palette.lightOutline,
    error: Palette.danger,
  );
  final background = dark ? Palette.darkBackground : Palette.lightBackground;
  final outline = BorderSide(color: scheme.outlineVariant);
  return ThemeData(
    useMaterial3: true,
    colorScheme: scheme,
    scaffoldBackgroundColor: background,
    appBarTheme: AppBarTheme(
      backgroundColor: background,
      surfaceTintColor: Colors.transparent,
      elevation: 0,
      centerTitle: false,
      titleTextStyle: TextStyle(
        fontSize: 22,
        fontWeight: FontWeight.w700,
        letterSpacing: -0.3,
        color: scheme.onSurface,
      ),
    ),
    cardTheme: CardThemeData(
      color: scheme.surface,
      elevation: 0,
      margin: EdgeInsets.zero,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: outline,
      ),
    ),
    navigationBarTheme: NavigationBarThemeData(
      backgroundColor: scheme.surface,
      surfaceTintColor: Colors.transparent,
      indicatorColor: scheme.primary.withValues(alpha: 0.18),
      height: 66,
      labelTextStyle: WidgetStateProperty.all(
        const TextStyle(fontSize: 12, fontWeight: FontWeight.w500),
      ),
    ),
    dividerTheme: DividerThemeData(color: scheme.outlineVariant, space: 1),
    filledButtonTheme: FilledButtonThemeData(
      style: FilledButton.styleFrom(
        minimumSize: const Size(0, 48),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      ),
    ),
    outlinedButtonTheme: OutlinedButtonThemeData(
      style: OutlinedButton.styleFrom(
        minimumSize: const Size(0, 48),
        side: outline,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      ),
    ),
    snackBarTheme: const SnackBarThemeData(behavior: SnackBarBehavior.floating),
    inputDecorationTheme: const InputDecorationTheme(border: OutlineInputBorder()),
  );
}

/// Tabular figures: live numbers do not move sideways when they change.
const TextStyle numericStyle = TextStyle(
  fontFeatures: [FontFeature.tabularFigures()],
  fontWeight: FontWeight.w600,
);
